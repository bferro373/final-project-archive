Set Current Bits
==============================

Set Current Bits to 16
----------------------------------------
**Description:** Set the current instruction to 16-bit.  

**Steps:** Right-click on an instruction and choose ``Set current bits to... -> 16``  

Set Current Bits to 32
----------------------------------------
**Description:** Set the current instruction to 32-bit.    

**Steps:** Right-click on an instruction and choose ``Set current bits to... -> 32``  

Set Current Bits to 64
----------------------------------------
**Description:** Set the current instruction to 64-bit.    

**Steps:** Right-click on an instruction and choose ``Set current bits to... -> 64``