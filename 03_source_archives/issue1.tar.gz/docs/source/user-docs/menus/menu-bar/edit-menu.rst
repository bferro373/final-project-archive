Edit Menu
==============================

Show Search Widget
----------------------------------------
**Description:** Show the Search widget  

**Steps:** Edit -> Search  

Go Back
----------------------------------------
**Description:** Seek backward to your previous location.  

**Steps:** Edit -> Undo Seek  

**Shortcut:** :kbd:`Alt` + :kbd:`Left`  

Redo Seek
----------------------------------------
**Description:** Seek forward a location.   

**Steps:** Edit -> Redo Seek  

**Shortcut:** :kbd:`Alt` + :kbd:`Right`  

Preferences
----------------------------------------
**Description:** Open the preferences dialog to access and define Cutter's configurations.  

**Steps:** Edit -> Preferences