#ifndef CRASHREPORTING_H
#define CRASHREPORTING_H

/**
 * @brief Opens issue on Cutter's github page
 * with current file and system information.
 */
void openIssue();

#endif // CRASHREPORTING_H
