Hexdump Widget Context Menu
==============================
.. toctree::
   :maxdepth: 1
   :glob:

   hexdump-context-menu/*

Bytes Per Row
----------------------------------------
**Description:** Select how many bytes should be displayed by Cutter in each row in the Hexdump widget.

Available options are:   
 - 1 byte
 - 2 bytes
 - 4 bytes
 - 8 bytes
 - 16 bytes
 - 32 bytes
 - Power of 2 (Auto)