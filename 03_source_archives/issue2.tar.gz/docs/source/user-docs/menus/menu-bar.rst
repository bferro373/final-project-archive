Menu Bar
========

Depending on your desktop environment menu bar is located either at the top of the window
or top of the screen.

.. toctree::
   :maxdepth: 2
   :glob:

   menu-bar/file-menu
   menu-bar/edit-menu
   menu-bar/view-menu
   menu-bar/windows-menu
   menu-bar/plugins-menu
   menu-bar/debug-menu
   menu-bar/debug-view-menu
   menu-bar/help-menu
   menu-bar/*

 
