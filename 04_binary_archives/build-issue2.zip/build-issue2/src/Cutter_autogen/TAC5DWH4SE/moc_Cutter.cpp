/****************************************************************************
** Meta object code from reading C++ file 'Cutter.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.8)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../../src/core/Cutter.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'Cutter.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_CutterCore_t {
    QByteArrayData data[47];
    char stringdata0[613];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_CutterCore_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_CutterCore_t qt_meta_stringdata_CutterCore = {
    {
QT_MOC_LITERAL(0, 0, 10), // "CutterCore"
QT_MOC_LITERAL(1, 11, 10), // "refreshAll"
QT_MOC_LITERAL(2, 22, 0), // ""
QT_MOC_LITERAL(3, 23, 15), // "functionRenamed"
QT_MOC_LITERAL(4, 39, 3), // "RVA"
QT_MOC_LITERAL(5, 43, 6), // "offset"
QT_MOC_LITERAL(6, 50, 8), // "new_name"
QT_MOC_LITERAL(7, 59, 11), // "varsChanged"
QT_MOC_LITERAL(8, 71, 17), // "globalVarsChanged"
QT_MOC_LITERAL(9, 89, 16), // "functionsChanged"
QT_MOC_LITERAL(10, 106, 12), // "flagsChanged"
QT_MOC_LITERAL(11, 119, 15), // "commentsChanged"
QT_MOC_LITERAL(12, 135, 4), // "addr"
QT_MOC_LITERAL(13, 140, 16), // "registersChanged"
QT_MOC_LITERAL(14, 157, 18), // "instructionChanged"
QT_MOC_LITERAL(15, 176, 18), // "breakpointsChanged"
QT_MOC_LITERAL(16, 195, 16), // "refreshCodeViews"
QT_MOC_LITERAL(17, 212, 12), // "stackChanged"
QT_MOC_LITERAL(18, 225, 11), // "codeRebased"
QT_MOC_LITERAL(19, 237, 14), // "switchedThread"
QT_MOC_LITERAL(20, 252, 15), // "switchedProcess"
QT_MOC_LITERAL(21, 268, 8), // "classNew"
QT_MOC_LITERAL(22, 277, 3), // "cls"
QT_MOC_LITERAL(23, 281, 12), // "classDeleted"
QT_MOC_LITERAL(24, 294, 12), // "classRenamed"
QT_MOC_LITERAL(25, 307, 7), // "oldName"
QT_MOC_LITERAL(26, 315, 7), // "newName"
QT_MOC_LITERAL(27, 323, 17), // "classAttrsChanged"
QT_MOC_LITERAL(28, 341, 20), // "debugProcessFinished"
QT_MOC_LITERAL(29, 362, 3), // "pid"
QT_MOC_LITERAL(30, 366, 14), // "attachedRemote"
QT_MOC_LITERAL(31, 381, 12), // "successfully"
QT_MOC_LITERAL(32, 394, 14), // "ioCacheChanged"
QT_MOC_LITERAL(33, 409, 6), // "newval"
QT_MOC_LITERAL(34, 416, 16), // "writeModeChanged"
QT_MOC_LITERAL(35, 433, 13), // "ioModeChanged"
QT_MOC_LITERAL(36, 447, 21), // "debugTaskStateChanged"
QT_MOC_LITERAL(37, 469, 17), // "asmOptionsChanged"
QT_MOC_LITERAL(38, 487, 19), // "graphOptionsChanged"
QT_MOC_LITERAL(39, 507, 11), // "seekChanged"
QT_MOC_LITERAL(40, 519, 15), // "SeekHistoryType"
QT_MOC_LITERAL(41, 535, 4), // "type"
QT_MOC_LITERAL(42, 540, 15), // "toggleDebugView"
QT_MOC_LITERAL(43, 556, 10), // "newMessage"
QT_MOC_LITERAL(44, 567, 3), // "msg"
QT_MOC_LITERAL(45, 571, 15), // "newDebugMessage"
QT_MOC_LITERAL(46, 587, 25) // "showMemoryWidgetRequested"

    },
    "CutterCore\0refreshAll\0\0functionRenamed\0"
    "RVA\0offset\0new_name\0varsChanged\0"
    "globalVarsChanged\0functionsChanged\0"
    "flagsChanged\0commentsChanged\0addr\0"
    "registersChanged\0instructionChanged\0"
    "breakpointsChanged\0refreshCodeViews\0"
    "stackChanged\0codeRebased\0switchedThread\0"
    "switchedProcess\0classNew\0cls\0classDeleted\0"
    "classRenamed\0oldName\0newName\0"
    "classAttrsChanged\0debugProcessFinished\0"
    "pid\0attachedRemote\0successfully\0"
    "ioCacheChanged\0newval\0writeModeChanged\0"
    "ioModeChanged\0debugTaskStateChanged\0"
    "asmOptionsChanged\0graphOptionsChanged\0"
    "seekChanged\0SeekHistoryType\0type\0"
    "toggleDebugView\0newMessage\0msg\0"
    "newDebugMessage\0showMemoryWidgetRequested"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_CutterCore[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      33,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      33,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  179,    2, 0x06 /* Public */,
       3,    2,  180,    2, 0x06 /* Public */,
       7,    0,  185,    2, 0x06 /* Public */,
       8,    0,  186,    2, 0x06 /* Public */,
       9,    0,  187,    2, 0x06 /* Public */,
      10,    0,  188,    2, 0x06 /* Public */,
      11,    1,  189,    2, 0x06 /* Public */,
      13,    0,  192,    2, 0x06 /* Public */,
      14,    1,  193,    2, 0x06 /* Public */,
      15,    1,  196,    2, 0x06 /* Public */,
      16,    0,  199,    2, 0x06 /* Public */,
      17,    0,  200,    2, 0x06 /* Public */,
      18,    0,  201,    2, 0x06 /* Public */,
      19,    0,  202,    2, 0x06 /* Public */,
      20,    0,  203,    2, 0x06 /* Public */,
      21,    1,  204,    2, 0x06 /* Public */,
      23,    1,  207,    2, 0x06 /* Public */,
      24,    2,  210,    2, 0x06 /* Public */,
      27,    1,  215,    2, 0x06 /* Public */,
      28,    1,  218,    2, 0x06 /* Public */,
      30,    1,  221,    2, 0x06 /* Public */,
      32,    1,  224,    2, 0x06 /* Public */,
      34,    1,  227,    2, 0x06 /* Public */,
      35,    0,  230,    2, 0x06 /* Public */,
      36,    0,  231,    2, 0x06 /* Public */,
      37,    0,  232,    2, 0x06 /* Public */,
      38,    0,  233,    2, 0x06 /* Public */,
      39,    2,  234,    2, 0x06 /* Public */,
      39,    1,  239,    2, 0x26 /* Public | MethodCloned */,
      42,    0,  242,    2, 0x06 /* Public */,
      43,    1,  243,    2, 0x06 /* Public */,
      45,    1,  246,    2, 0x06 /* Public */,
      46,    0,  249,    2, 0x06 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 4, QMetaType::QString,    5,    6,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 4,   12,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 4,    5,
    QMetaType::Void, 0x80000000 | 4,    5,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   22,
    QMetaType::Void, QMetaType::QString,   22,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,   25,   26,
    QMetaType::Void, QMetaType::QString,   22,
    QMetaType::Void, QMetaType::Int,   29,
    QMetaType::Void, QMetaType::Bool,   31,
    QMetaType::Void, QMetaType::Bool,   33,
    QMetaType::Void, QMetaType::Bool,   33,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 4, 0x80000000 | 40,    5,   41,
    QMetaType::Void, 0x80000000 | 4,    5,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   44,
    QMetaType::Void, QMetaType::QString,   44,
    QMetaType::Void,

       0        // eod
};

void CutterCore::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<CutterCore *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->refreshAll(); break;
        case 1: _t->functionRenamed((*reinterpret_cast< const RVA(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 2: _t->varsChanged(); break;
        case 3: _t->globalVarsChanged(); break;
        case 4: _t->functionsChanged(); break;
        case 5: _t->flagsChanged(); break;
        case 6: _t->commentsChanged((*reinterpret_cast< RVA(*)>(_a[1]))); break;
        case 7: _t->registersChanged(); break;
        case 8: _t->instructionChanged((*reinterpret_cast< RVA(*)>(_a[1]))); break;
        case 9: _t->breakpointsChanged((*reinterpret_cast< RVA(*)>(_a[1]))); break;
        case 10: _t->refreshCodeViews(); break;
        case 11: _t->stackChanged(); break;
        case 12: _t->codeRebased(); break;
        case 13: _t->switchedThread(); break;
        case 14: _t->switchedProcess(); break;
        case 15: _t->classNew((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 16: _t->classDeleted((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 17: _t->classRenamed((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 18: _t->classAttrsChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 19: _t->debugProcessFinished((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 20: _t->attachedRemote((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 21: _t->ioCacheChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 22: _t->writeModeChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 23: _t->ioModeChanged(); break;
        case 24: _t->debugTaskStateChanged(); break;
        case 25: _t->asmOptionsChanged(); break;
        case 26: _t->graphOptionsChanged(); break;
        case 27: _t->seekChanged((*reinterpret_cast< RVA(*)>(_a[1])),(*reinterpret_cast< SeekHistoryType(*)>(_a[2]))); break;
        case 28: _t->seekChanged((*reinterpret_cast< RVA(*)>(_a[1]))); break;
        case 29: _t->toggleDebugView(); break;
        case 30: _t->newMessage((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 31: _t->newDebugMessage((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 32: _t->showMemoryWidgetRequested(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (CutterCore::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::refreshAll)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)(const RVA , const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::functionRenamed)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::varsChanged)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::globalVarsChanged)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::functionsChanged)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::flagsChanged)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)(RVA );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::commentsChanged)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::registersChanged)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)(RVA );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::instructionChanged)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)(RVA );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::breakpointsChanged)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::refreshCodeViews)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::stackChanged)) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::codeRebased)) {
                *result = 12;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::switchedThread)) {
                *result = 13;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::switchedProcess)) {
                *result = 14;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::classNew)) {
                *result = 15;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::classDeleted)) {
                *result = 16;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)(const QString & , const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::classRenamed)) {
                *result = 17;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::classAttrsChanged)) {
                *result = 18;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::debugProcessFinished)) {
                *result = 19;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::attachedRemote)) {
                *result = 20;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::ioCacheChanged)) {
                *result = 21;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::writeModeChanged)) {
                *result = 22;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::ioModeChanged)) {
                *result = 23;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::debugTaskStateChanged)) {
                *result = 24;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::asmOptionsChanged)) {
                *result = 25;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::graphOptionsChanged)) {
                *result = 26;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)(RVA , SeekHistoryType );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::seekChanged)) {
                *result = 27;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::toggleDebugView)) {
                *result = 29;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::newMessage)) {
                *result = 30;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::newDebugMessage)) {
                *result = 31;
                return;
            }
        }
        {
            using _t = void (CutterCore::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CutterCore::showMemoryWidgetRequested)) {
                *result = 32;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject CutterCore::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_CutterCore.data,
    qt_meta_data_CutterCore,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *CutterCore::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *CutterCore::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CutterCore.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int CutterCore::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 33)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 33;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 33)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 33;
    }
    return _id;
}

// SIGNAL 0
void CutterCore::refreshAll()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void CutterCore::functionRenamed(const RVA _t1, const QString & _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void CutterCore::varsChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void CutterCore::globalVarsChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void CutterCore::functionsChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void CutterCore::flagsChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void CutterCore::commentsChanged(RVA _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void CutterCore::registersChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 7, nullptr);
}

// SIGNAL 8
void CutterCore::instructionChanged(RVA _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void CutterCore::breakpointsChanged(RVA _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void CutterCore::refreshCodeViews()
{
    QMetaObject::activate(this, &staticMetaObject, 10, nullptr);
}

// SIGNAL 11
void CutterCore::stackChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 11, nullptr);
}

// SIGNAL 12
void CutterCore::codeRebased()
{
    QMetaObject::activate(this, &staticMetaObject, 12, nullptr);
}

// SIGNAL 13
void CutterCore::switchedThread()
{
    QMetaObject::activate(this, &staticMetaObject, 13, nullptr);
}

// SIGNAL 14
void CutterCore::switchedProcess()
{
    QMetaObject::activate(this, &staticMetaObject, 14, nullptr);
}

// SIGNAL 15
void CutterCore::classNew(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 15, _a);
}

// SIGNAL 16
void CutterCore::classDeleted(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 16, _a);
}

// SIGNAL 17
void CutterCore::classRenamed(const QString & _t1, const QString & _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 17, _a);
}

// SIGNAL 18
void CutterCore::classAttrsChanged(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 18, _a);
}

// SIGNAL 19
void CutterCore::debugProcessFinished(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 19, _a);
}

// SIGNAL 20
void CutterCore::attachedRemote(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 20, _a);
}

// SIGNAL 21
void CutterCore::ioCacheChanged(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 21, _a);
}

// SIGNAL 22
void CutterCore::writeModeChanged(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 22, _a);
}

// SIGNAL 23
void CutterCore::ioModeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 23, nullptr);
}

// SIGNAL 24
void CutterCore::debugTaskStateChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 24, nullptr);
}

// SIGNAL 25
void CutterCore::asmOptionsChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 25, nullptr);
}

// SIGNAL 26
void CutterCore::graphOptionsChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 26, nullptr);
}

// SIGNAL 27
void CutterCore::seekChanged(RVA _t1, SeekHistoryType _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 27, _a);
}

// SIGNAL 29
void CutterCore::toggleDebugView()
{
    QMetaObject::activate(this, &staticMetaObject, 29, nullptr);
}

// SIGNAL 30
void CutterCore::newMessage(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 30, _a);
}

// SIGNAL 31
void CutterCore::newDebugMessage(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 31, _a);
}

// SIGNAL 32
void CutterCore::showMemoryWidgetRequested()
{
    QMetaObject::activate(this, &staticMetaObject, 32, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
