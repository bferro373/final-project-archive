/****************************************************************************
** Meta object code from reading C++ file 'AsmOptionsWidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.8)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../../src/dialogs/preferences/AsmOptionsWidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'AsmOptionsWidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_AsmOptionsWidget_t {
    QByteArrayData data[27];
    char stringdata0[530];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_AsmOptionsWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_AsmOptionsWidget_t qt_meta_stringdata_AsmOptionsWidget = {
    {
QT_MOC_LITERAL(0, 0, 16), // "AsmOptionsWidget"
QT_MOC_LITERAL(1, 17, 14), // "resetToDefault"
QT_MOC_LITERAL(2, 32, 0), // ""
QT_MOC_LITERAL(3, 33, 24), // "updateAsmOptionsFromVars"
QT_MOC_LITERAL(4, 58, 29), // "on_cmtcolSpinBox_valueChanged"
QT_MOC_LITERAL(5, 88, 5), // "value"
QT_MOC_LITERAL(6, 94, 37), // "on_syntaxComboBox_currentInde..."
QT_MOC_LITERAL(7, 132, 5), // "index"
QT_MOC_LITERAL(8, 138, 35), // "on_caseComboBox_currentIndexC..."
QT_MOC_LITERAL(9, 174, 30), // "on_asmTabsSpinBox_valueChanged"
QT_MOC_LITERAL(10, 205, 33), // "on_asmTabsOffSpinBox_valueCha..."
QT_MOC_LITERAL(11, 239, 29), // "on_nbytesSpinBox_valueChanged"
QT_MOC_LITERAL(12, 269, 24), // "on_bytesCheckBox_toggled"
QT_MOC_LITERAL(13, 294, 7), // "checked"
QT_MOC_LITERAL(14, 302, 25), // "on_varsubCheckBox_toggled"
QT_MOC_LITERAL(15, 328, 26), // "on_previewCheckBox_toggled"
QT_MOC_LITERAL(16, 355, 20), // "on_buttonBox_clicked"
QT_MOC_LITERAL(17, 376, 16), // "QAbstractButton*"
QT_MOC_LITERAL(18, 393, 6), // "button"
QT_MOC_LITERAL(19, 400, 23), // "commentsComboBoxChanged"
QT_MOC_LITERAL(20, 424, 18), // "asmComboBoxChanged"
QT_MOC_LITERAL(21, 443, 21), // "offsetCheckBoxToggled"
QT_MOC_LITERAL(22, 465, 21), // "relOffCheckBoxToggled"
QT_MOC_LITERAL(23, 487, 15), // "checkboxEnabler"
QT_MOC_LITERAL(24, 503, 10), // "QCheckBox*"
QT_MOC_LITERAL(25, 514, 8), // "checkbox"
QT_MOC_LITERAL(26, 523, 6) // "config"

    },
    "AsmOptionsWidget\0resetToDefault\0\0"
    "updateAsmOptionsFromVars\0"
    "on_cmtcolSpinBox_valueChanged\0value\0"
    "on_syntaxComboBox_currentIndexChanged\0"
    "index\0on_caseComboBox_currentIndexChanged\0"
    "on_asmTabsSpinBox_valueChanged\0"
    "on_asmTabsOffSpinBox_valueChanged\0"
    "on_nbytesSpinBox_valueChanged\0"
    "on_bytesCheckBox_toggled\0checked\0"
    "on_varsubCheckBox_toggled\0"
    "on_previewCheckBox_toggled\0"
    "on_buttonBox_clicked\0QAbstractButton*\0"
    "button\0commentsComboBoxChanged\0"
    "asmComboBoxChanged\0offsetCheckBoxToggled\0"
    "relOffCheckBoxToggled\0checkboxEnabler\0"
    "QCheckBox*\0checkbox\0config"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_AsmOptionsWidget[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      17,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   99,    2, 0x08 /* Private */,
       3,    0,  100,    2, 0x08 /* Private */,
       4,    1,  101,    2, 0x08 /* Private */,
       6,    1,  104,    2, 0x08 /* Private */,
       8,    1,  107,    2, 0x08 /* Private */,
       9,    1,  110,    2, 0x08 /* Private */,
      10,    1,  113,    2, 0x08 /* Private */,
      11,    1,  116,    2, 0x08 /* Private */,
      12,    1,  119,    2, 0x08 /* Private */,
      14,    1,  122,    2, 0x08 /* Private */,
      15,    1,  125,    2, 0x08 /* Private */,
      16,    1,  128,    2, 0x08 /* Private */,
      19,    1,  131,    2, 0x08 /* Private */,
      20,    1,  134,    2, 0x08 /* Private */,
      21,    1,  137,    2, 0x08 /* Private */,
      22,    1,  140,    2, 0x08 /* Private */,
      23,    2,  143,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::Bool,   13,
    QMetaType::Void, QMetaType::Bool,   13,
    QMetaType::Void, QMetaType::Bool,   13,
    QMetaType::Void, 0x80000000 | 17,   18,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void, QMetaType::Int,    7,
    QMetaType::Void, QMetaType::Bool,   13,
    QMetaType::Void, QMetaType::Bool,   13,
    QMetaType::Void, 0x80000000 | 24, QMetaType::QString,   25,   26,

       0        // eod
};

void AsmOptionsWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<AsmOptionsWidget *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->resetToDefault(); break;
        case 1: _t->updateAsmOptionsFromVars(); break;
        case 2: _t->on_cmtcolSpinBox_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->on_syntaxComboBox_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->on_caseComboBox_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->on_asmTabsSpinBox_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->on_asmTabsOffSpinBox_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->on_nbytesSpinBox_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->on_bytesCheckBox_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 9: _t->on_varsubCheckBox_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 10: _t->on_previewCheckBox_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 11: _t->on_buttonBox_clicked((*reinterpret_cast< QAbstractButton*(*)>(_a[1]))); break;
        case 12: _t->commentsComboBoxChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 13: _t->asmComboBoxChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->offsetCheckBoxToggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 15: _t->relOffCheckBoxToggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 16: _t->checkboxEnabler((*reinterpret_cast< QCheckBox*(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 11:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QAbstractButton* >(); break;
            }
            break;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject AsmOptionsWidget::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_meta_stringdata_AsmOptionsWidget.data,
    qt_meta_data_AsmOptionsWidget,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *AsmOptionsWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *AsmOptionsWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_AsmOptionsWidget.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int AsmOptionsWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 17)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 17;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 17)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 17;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
