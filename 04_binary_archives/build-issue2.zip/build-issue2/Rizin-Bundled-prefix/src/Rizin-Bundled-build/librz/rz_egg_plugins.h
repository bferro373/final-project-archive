// SPDX-FileCopyrightText: 2024 RizinOrg <info@rizin.re>
// SPDX-License-Identifier: LGPL-3.0-only

// clang-format off
#ifndef RZ_EGG_PLUGINS_BUILD_H
#define RZ_EGG_PLUGINS_BUILD_H

#define RZ_EGG_STATIC_PLUGINS &rz_egg_plugin_exec, &rz_egg_plugin_xor

extern RzEggPlugin rz_egg_plugin_exec;
extern RzEggPlugin rz_egg_plugin_xor;
// clang-format on

#endif