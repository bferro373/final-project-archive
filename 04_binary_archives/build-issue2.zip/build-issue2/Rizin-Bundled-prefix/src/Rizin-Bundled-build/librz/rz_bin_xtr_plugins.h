// SPDX-FileCopyrightText: 2024 RizinOrg <info@rizin.re>
// SPDX-License-Identifier: LGPL-3.0-only

// clang-format off
#ifndef RZ_BIN_XTR_PLUGINS_BUILD_H
#define RZ_BIN_XTR_PLUGINS_BUILD_H

#define RZ_BIN_XTR_STATIC_PLUGINS &rz_bin_xtr_plugin_fatmach0, &rz_bin_xtr_plugin_sep64

extern RzBinXtrPlugin rz_bin_xtr_plugin_fatmach0;
extern RzBinXtrPlugin rz_bin_xtr_plugin_sep64;
// clang-format on

#endif