// SPDX-FileCopyrightText: 2024 RizinOrg <info@rizin.re>
// SPDX-License-Identifier: LGPL-3.0-only

// clang-format off
#ifndef RZ_BIN_PLUGINS_BUILD_H
#define RZ_BIN_PLUGINS_BUILD_H

#define RZ_BIN_STATIC_PLUGINS &rz_bin_plugin_any, &rz_bin_plugin_art, &rz_bin_plugin_avr, &rz_bin_plugin_bf, &rz_bin_plugin_bflt, &rz_bin_plugin_bios, &rz_bin_plugin_bootimg, &rz_bin_plugin_cgc, &rz_bin_plugin_coff, &rz_bin_plugin_dex, &rz_bin_plugin_dmp64, &rz_bin_plugin_dol, &rz_bin_plugin_dyldcache, &rz_bin_plugin_elf, &rz_bin_plugin_elf64, &rz_bin_plugin_java, &rz_bin_plugin_le, &rz_bin_plugin_luac, &rz_bin_plugin_mach0, &rz_bin_plugin_mach064, &rz_bin_plugin_mbn, &rz_bin_plugin_mdmp, &rz_bin_plugin_menuet, &rz_bin_plugin_mz, &rz_bin_plugin_ne, &rz_bin_plugin_nes, &rz_bin_plugin_nin3ds, &rz_bin_plugin_ninds, &rz_bin_plugin_ningb, &rz_bin_plugin_ningba, &rz_bin_plugin_nro, &rz_bin_plugin_nso, &rz_bin_plugin_omf, &rz_bin_plugin_qnx, &rz_bin_plugin_p9, &rz_bin_plugin_pe, &rz_bin_plugin_pe64, &rz_bin_plugin_pebble, &rz_bin_plugin_prg, &rz_bin_plugin_psxexe, &rz_bin_plugin_pyc, &rz_bin_plugin_sfc, &rz_bin_plugin_smd, &rz_bin_plugin_sms, &rz_bin_plugin_spc700, &rz_bin_plugin_symbols, &rz_bin_plugin_te, &rz_bin_plugin_vsf, &rz_bin_plugin_wasm, &rz_bin_plugin_xbe, &rz_bin_plugin_xnu_kernelcache, &rz_bin_plugin_z64, &rz_bin_plugin_zimg

extern RzBinPlugin rz_bin_plugin_any;
extern RzBinPlugin rz_bin_plugin_art;
extern RzBinPlugin rz_bin_plugin_avr;
extern RzBinPlugin rz_bin_plugin_bf;
extern RzBinPlugin rz_bin_plugin_bflt;
extern RzBinPlugin rz_bin_plugin_bios;
extern RzBinPlugin rz_bin_plugin_bootimg;
extern RzBinPlugin rz_bin_plugin_cgc;
extern RzBinPlugin rz_bin_plugin_coff;
extern RzBinPlugin rz_bin_plugin_dex;
extern RzBinPlugin rz_bin_plugin_dmp64;
extern RzBinPlugin rz_bin_plugin_dol;
extern RzBinPlugin rz_bin_plugin_dyldcache;
extern RzBinPlugin rz_bin_plugin_elf;
extern RzBinPlugin rz_bin_plugin_elf64;
extern RzBinPlugin rz_bin_plugin_java;
extern RzBinPlugin rz_bin_plugin_le;
extern RzBinPlugin rz_bin_plugin_luac;
extern RzBinPlugin rz_bin_plugin_mach0;
extern RzBinPlugin rz_bin_plugin_mach064;
extern RzBinPlugin rz_bin_plugin_mbn;
extern RzBinPlugin rz_bin_plugin_mdmp;
extern RzBinPlugin rz_bin_plugin_menuet;
extern RzBinPlugin rz_bin_plugin_mz;
extern RzBinPlugin rz_bin_plugin_ne;
extern RzBinPlugin rz_bin_plugin_nes;
extern RzBinPlugin rz_bin_plugin_nin3ds;
extern RzBinPlugin rz_bin_plugin_ninds;
extern RzBinPlugin rz_bin_plugin_ningb;
extern RzBinPlugin rz_bin_plugin_ningba;
extern RzBinPlugin rz_bin_plugin_nro;
extern RzBinPlugin rz_bin_plugin_nso;
extern RzBinPlugin rz_bin_plugin_omf;
extern RzBinPlugin rz_bin_plugin_qnx;
extern RzBinPlugin rz_bin_plugin_p9;
extern RzBinPlugin rz_bin_plugin_pe;
extern RzBinPlugin rz_bin_plugin_pe64;
extern RzBinPlugin rz_bin_plugin_pebble;
extern RzBinPlugin rz_bin_plugin_prg;
extern RzBinPlugin rz_bin_plugin_psxexe;
extern RzBinPlugin rz_bin_plugin_pyc;
extern RzBinPlugin rz_bin_plugin_sfc;
extern RzBinPlugin rz_bin_plugin_smd;
extern RzBinPlugin rz_bin_plugin_sms;
extern RzBinPlugin rz_bin_plugin_spc700;
extern RzBinPlugin rz_bin_plugin_symbols;
extern RzBinPlugin rz_bin_plugin_te;
extern RzBinPlugin rz_bin_plugin_vsf;
extern RzBinPlugin rz_bin_plugin_wasm;
extern RzBinPlugin rz_bin_plugin_xbe;
extern RzBinPlugin rz_bin_plugin_xnu_kernelcache;
extern RzBinPlugin rz_bin_plugin_z64;
extern RzBinPlugin rz_bin_plugin_zimg;
// clang-format on

#endif