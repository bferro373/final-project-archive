// SPDX-FileCopyrightText: 2024 RizinOrg <info@rizin.re>
// SPDX-License-Identifier: LGPL-3.0-only

// clang-format off
#ifndef RZ_CORE_PLUGINS_BUILD_H
#define RZ_CORE_PLUGINS_BUILD_H

#define RZ_CORE_STATIC_PLUGINS &rz_core_plugin_java, &rz_core_plugin_dex

extern RzCorePlugin rz_core_plugin_java;
extern RzCorePlugin rz_core_plugin_dex;
// clang-format on

#endif