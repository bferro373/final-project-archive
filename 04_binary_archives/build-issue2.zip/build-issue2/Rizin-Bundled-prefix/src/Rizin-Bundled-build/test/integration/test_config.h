// SPDX-FileCopyrightText: 2021 RizinOrg <info@rizin.re>
// SPDX-License-Identifier: LGPL-3.0-only

#ifndef _TEST_CONFIG_H_
#define _TEST_CONFIG_H_

#define RIZIN_BUILD_PATH "/Users/rohansagar/Documents/GitHub/ECE49595-OSS/build/Rizin-Bundled-prefix/src/Rizin-Bundled-build/binrz/rizin/rizin"
#define TEST_BUILD_TYPES_DIR "/Users/rohansagar/Documents/GitHub/ECE49595-OSS/build/Rizin-Bundled-prefix/src/Rizin-Bundled-build/librz/arch/types"

#endif /* _TEST_CONFIG_H_ */
