/****************************************************************************
** Meta object code from reading C++ file 'MainWindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.8)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../../src/core/MainWindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'MainWindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[60];
    char stringdata0[1214];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 12), // "finalizeOpen"
QT_MOC_LITERAL(2, 24, 0), // ""
QT_MOC_LITERAL(3, 25, 10), // "refreshAll"
QT_MOC_LITERAL(4, 36, 29), // "seekToFunctionLastInstruction"
QT_MOC_LITERAL(5, 66, 19), // "seekToFunctionStart"
QT_MOC_LITERAL(6, 86, 14), // "setTabLocation"
QT_MOC_LITERAL(7, 101, 23), // "on_actionTabs_triggered"
QT_MOC_LITERAL(8, 125, 26), // "on_actionAnalyze_triggered"
QT_MOC_LITERAL(9, 152, 9), // "lockDocks"
QT_MOC_LITERAL(10, 162, 4), // "lock"
QT_MOC_LITERAL(11, 167, 29), // "on_actionRun_Script_triggered"
QT_MOC_LITERAL(12, 197, 16), // "toggleResponsive"
QT_MOC_LITERAL(13, 214, 5), // "maybe"
QT_MOC_LITERAL(14, 220, 17), // "openNewFileFailed"
QT_MOC_LITERAL(15, 238, 14), // "toggleOverview"
QT_MOC_LITERAL(16, 253, 10), // "visibility"
QT_MOC_LITERAL(17, 264, 12), // "GraphWidget*"
QT_MOC_LITERAL(18, 277, 11), // "targetGraph"
QT_MOC_LITERAL(19, 289, 27), // "on_actionBaseFind_triggered"
QT_MOC_LITERAL(20, 317, 24), // "on_actionAbout_triggered"
QT_MOC_LITERAL(21, 342, 24), // "on_actionIssue_triggered"
QT_MOC_LITERAL(22, 367, 20), // "documentationClicked"
QT_MOC_LITERAL(23, 388, 13), // "addExtraGraph"
QT_MOC_LITERAL(24, 402, 15), // "addExtraHexdump"
QT_MOC_LITERAL(25, 418, 19), // "addExtraDisassembly"
QT_MOC_LITERAL(26, 438, 18), // "addExtraDecompiler"
QT_MOC_LITERAL(27, 457, 33), // "on_actionRefresh_Panels_trigg..."
QT_MOC_LITERAL(28, 491, 35), // "on_actionDisasAdd_comment_tri..."
QT_MOC_LITERAL(29, 527, 26), // "on_actionDefault_triggered"
QT_MOC_LITERAL(30, 554, 22), // "on_actionNew_triggered"
QT_MOC_LITERAL(31, 577, 23), // "on_actionSave_triggered"
QT_MOC_LITERAL(32, 601, 25), // "on_actionSaveAs_triggered"
QT_MOC_LITERAL(33, 627, 27), // "on_actionBackward_triggered"
QT_MOC_LITERAL(34, 655, 26), // "on_actionForward_triggered"
QT_MOC_LITERAL(35, 682, 22), // "on_actionMap_triggered"
QT_MOC_LITERAL(36, 705, 30), // "on_actionTabs_on_Top_triggered"
QT_MOC_LITERAL(37, 736, 33), // "on_actionReset_settings_trigg..."
QT_MOC_LITERAL(38, 770, 23), // "on_actionQuit_triggered"
QT_MOC_LITERAL(39, 794, 35), // "on_actionRefresh_contents_tri..."
QT_MOC_LITERAL(40, 830, 30), // "on_actionPreferences_triggered"
QT_MOC_LITERAL(41, 861, 28), // "on_actionImportPDB_triggered"
QT_MOC_LITERAL(42, 890, 33), // "on_actionExport_as_code_trigg..."
QT_MOC_LITERAL(43, 924, 35), // "on_actionApplySigFromFile_tri..."
QT_MOC_LITERAL(44, 960, 31), // "on_actionCreateNewSig_triggered"
QT_MOC_LITERAL(45, 992, 40), // "on_actionGrouped_dock_draggin..."
QT_MOC_LITERAL(46, 1033, 7), // "checked"
QT_MOC_LITERAL(47, 1041, 20), // "updateTasksIndicator"
QT_MOC_LITERAL(48, 1062, 15), // "mousePressEvent"
QT_MOC_LITERAL(49, 1078, 12), // "QMouseEvent*"
QT_MOC_LITERAL(50, 1091, 5), // "event"
QT_MOC_LITERAL(51, 1097, 11), // "eventFilter"
QT_MOC_LITERAL(52, 1109, 6), // "object"
QT_MOC_LITERAL(53, 1116, 7), // "QEvent*"
QT_MOC_LITERAL(54, 1124, 15), // "toggleDebugView"
QT_MOC_LITERAL(55, 1140, 16), // "chooseThemeIcons"
QT_MOC_LITERAL(56, 1157, 8), // "onZoomIn"
QT_MOC_LITERAL(57, 1166, 9), // "onZoomOut"
QT_MOC_LITERAL(58, 1176, 11), // "onZoomReset"
QT_MOC_LITERAL(59, 1188, 25) // "setAvailableIOModeOptions"

    },
    "MainWindow\0finalizeOpen\0\0refreshAll\0"
    "seekToFunctionLastInstruction\0"
    "seekToFunctionStart\0setTabLocation\0"
    "on_actionTabs_triggered\0"
    "on_actionAnalyze_triggered\0lockDocks\0"
    "lock\0on_actionRun_Script_triggered\0"
    "toggleResponsive\0maybe\0openNewFileFailed\0"
    "toggleOverview\0visibility\0GraphWidget*\0"
    "targetGraph\0on_actionBaseFind_triggered\0"
    "on_actionAbout_triggered\0"
    "on_actionIssue_triggered\0documentationClicked\0"
    "addExtraGraph\0addExtraHexdump\0"
    "addExtraDisassembly\0addExtraDecompiler\0"
    "on_actionRefresh_Panels_triggered\0"
    "on_actionDisasAdd_comment_triggered\0"
    "on_actionDefault_triggered\0"
    "on_actionNew_triggered\0on_actionSave_triggered\0"
    "on_actionSaveAs_triggered\0"
    "on_actionBackward_triggered\0"
    "on_actionForward_triggered\0"
    "on_actionMap_triggered\0"
    "on_actionTabs_on_Top_triggered\0"
    "on_actionReset_settings_triggered\0"
    "on_actionQuit_triggered\0"
    "on_actionRefresh_contents_triggered\0"
    "on_actionPreferences_triggered\0"
    "on_actionImportPDB_triggered\0"
    "on_actionExport_as_code_triggered\0"
    "on_actionApplySigFromFile_triggered\0"
    "on_actionCreateNewSig_triggered\0"
    "on_actionGrouped_dock_dragging_triggered\0"
    "checked\0updateTasksIndicator\0"
    "mousePressEvent\0QMouseEvent*\0event\0"
    "eventFilter\0object\0QEvent*\0toggleDebugView\0"
    "chooseThemeIcons\0onZoomIn\0onZoomOut\0"
    "onZoomReset\0setAvailableIOModeOptions"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      49,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  259,    2, 0x0a /* Public */,
       3,    0,  260,    2, 0x0a /* Public */,
       4,    0,  261,    2, 0x0a /* Public */,
       5,    0,  262,    2, 0x0a /* Public */,
       6,    0,  263,    2, 0x0a /* Public */,
       7,    0,  264,    2, 0x0a /* Public */,
       8,    0,  265,    2, 0x0a /* Public */,
       9,    1,  266,    2, 0x0a /* Public */,
      11,    0,  269,    2, 0x0a /* Public */,
      12,    1,  270,    2, 0x0a /* Public */,
      14,    0,  273,    2, 0x0a /* Public */,
      15,    2,  274,    2, 0x0a /* Public */,
      19,    0,  279,    2, 0x08 /* Private */,
      20,    0,  280,    2, 0x08 /* Private */,
      21,    0,  281,    2, 0x08 /* Private */,
      22,    0,  282,    2, 0x08 /* Private */,
      23,    0,  283,    2, 0x08 /* Private */,
      24,    0,  284,    2, 0x08 /* Private */,
      25,    0,  285,    2, 0x08 /* Private */,
      26,    0,  286,    2, 0x08 /* Private */,
      27,    0,  287,    2, 0x08 /* Private */,
      28,    0,  288,    2, 0x08 /* Private */,
      29,    0,  289,    2, 0x08 /* Private */,
      30,    0,  290,    2, 0x08 /* Private */,
      31,    0,  291,    2, 0x08 /* Private */,
      32,    0,  292,    2, 0x08 /* Private */,
      33,    0,  293,    2, 0x08 /* Private */,
      34,    0,  294,    2, 0x08 /* Private */,
      35,    0,  295,    2, 0x08 /* Private */,
      36,    0,  296,    2, 0x08 /* Private */,
      37,    0,  297,    2, 0x08 /* Private */,
      38,    0,  298,    2, 0x08 /* Private */,
      39,    0,  299,    2, 0x08 /* Private */,
      40,    0,  300,    2, 0x08 /* Private */,
      41,    0,  301,    2, 0x08 /* Private */,
      42,    0,  302,    2, 0x08 /* Private */,
      43,    0,  303,    2, 0x08 /* Private */,
      44,    0,  304,    2, 0x08 /* Private */,
      45,    1,  305,    2, 0x08 /* Private */,
      47,    0,  308,    2, 0x08 /* Private */,
      48,    1,  309,    2, 0x08 /* Private */,
      51,    2,  312,    2, 0x08 /* Private */,
      50,    1,  317,    2, 0x08 /* Private */,
      54,    0,  320,    2, 0x08 /* Private */,
      55,    0,  321,    2, 0x08 /* Private */,
      56,    0,  322,    2, 0x08 /* Private */,
      57,    0,  323,    2, 0x08 /* Private */,
      58,    0,  324,    2, 0x08 /* Private */,
      59,    0,  325,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   10,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   13,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool, 0x80000000 | 17,   16,   18,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   46,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 49,   50,
    QMetaType::Bool, QMetaType::QObjectStar, 0x80000000 | 53,   52,   50,
    QMetaType::Bool, 0x80000000 | 53,   50,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->finalizeOpen(); break;
        case 1: _t->refreshAll(); break;
        case 2: _t->seekToFunctionLastInstruction(); break;
        case 3: _t->seekToFunctionStart(); break;
        case 4: _t->setTabLocation(); break;
        case 5: _t->on_actionTabs_triggered(); break;
        case 6: _t->on_actionAnalyze_triggered(); break;
        case 7: _t->lockDocks((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 8: _t->on_actionRun_Script_triggered(); break;
        case 9: _t->toggleResponsive((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 10: _t->openNewFileFailed(); break;
        case 11: _t->toggleOverview((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< GraphWidget*(*)>(_a[2]))); break;
        case 12: _t->on_actionBaseFind_triggered(); break;
        case 13: _t->on_actionAbout_triggered(); break;
        case 14: _t->on_actionIssue_triggered(); break;
        case 15: _t->documentationClicked(); break;
        case 16: _t->addExtraGraph(); break;
        case 17: _t->addExtraHexdump(); break;
        case 18: _t->addExtraDisassembly(); break;
        case 19: _t->addExtraDecompiler(); break;
        case 20: _t->on_actionRefresh_Panels_triggered(); break;
        case 21: _t->on_actionDisasAdd_comment_triggered(); break;
        case 22: _t->on_actionDefault_triggered(); break;
        case 23: _t->on_actionNew_triggered(); break;
        case 24: _t->on_actionSave_triggered(); break;
        case 25: _t->on_actionSaveAs_triggered(); break;
        case 26: _t->on_actionBackward_triggered(); break;
        case 27: _t->on_actionForward_triggered(); break;
        case 28: _t->on_actionMap_triggered(); break;
        case 29: _t->on_actionTabs_on_Top_triggered(); break;
        case 30: _t->on_actionReset_settings_triggered(); break;
        case 31: _t->on_actionQuit_triggered(); break;
        case 32: _t->on_actionRefresh_contents_triggered(); break;
        case 33: _t->on_actionPreferences_triggered(); break;
        case 34: _t->on_actionImportPDB_triggered(); break;
        case 35: _t->on_actionExport_as_code_triggered(); break;
        case 36: _t->on_actionApplySigFromFile_triggered(); break;
        case 37: _t->on_actionCreateNewSig_triggered(); break;
        case 38: _t->on_actionGrouped_dock_dragging_triggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 39: _t->updateTasksIndicator(); break;
        case 40: _t->mousePressEvent((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 41: { bool _r = _t->eventFilter((*reinterpret_cast< QObject*(*)>(_a[1])),(*reinterpret_cast< QEvent*(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 42: { bool _r = _t->event((*reinterpret_cast< QEvent*(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 43: _t->toggleDebugView(); break;
        case 44: _t->chooseThemeIcons(); break;
        case 45: _t->onZoomIn(); break;
        case 46: _t->onZoomOut(); break;
        case 47: _t->onZoomReset(); break;
        case 48: _t->setAvailableIOModeOptions(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 49)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 49;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 49)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 49;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
