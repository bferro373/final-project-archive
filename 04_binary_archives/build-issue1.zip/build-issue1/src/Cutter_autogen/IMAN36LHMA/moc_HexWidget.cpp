/****************************************************************************
** Meta object code from reading C++ file 'HexWidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.8)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../../src/widgets/HexWidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'HexWidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_HexWidget_t {
    QByteArrayData data[36];
    char stringdata0[531];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_HexWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_HexWidget_t qt_meta_stringdata_HexWidget = {
    {
QT_MOC_LITERAL(0, 0, 9), // "HexWidget"
QT_MOC_LITERAL(1, 10, 16), // "selectionChanged"
QT_MOC_LITERAL(2, 27, 0), // ""
QT_MOC_LITERAL(3, 28, 20), // "HexWidget::Selection"
QT_MOC_LITERAL(4, 49, 9), // "selection"
QT_MOC_LITERAL(5, 59, 15), // "positionChanged"
QT_MOC_LITERAL(6, 75, 3), // "RVA"
QT_MOC_LITERAL(7, 79, 5), // "start"
QT_MOC_LITERAL(8, 85, 4), // "seek"
QT_MOC_LITERAL(9, 90, 8), // "uint64_t"
QT_MOC_LITERAL(10, 99, 7), // "address"
QT_MOC_LITERAL(11, 107, 7), // "refresh"
QT_MOC_LITERAL(12, 115, 12), // "updateColors"
QT_MOC_LITERAL(13, 128, 15), // "onCursorBlinked"
QT_MOC_LITERAL(14, 144, 21), // "onHexPairsModeEnabled"
QT_MOC_LITERAL(15, 166, 6), // "enable"
QT_MOC_LITERAL(16, 173, 4), // "copy"
QT_MOC_LITERAL(17, 178, 11), // "copyAddress"
QT_MOC_LITERAL(18, 190, 21), // "onRangeDialogAccepted"
QT_MOC_LITERAL(19, 212, 27), // "onActionAddCommentTriggered"
QT_MOC_LITERAL(20, 240, 24), // "onActionAddFlagTriggered"
QT_MOC_LITERAL(21, 265, 27), // "onActionDeleteFlagTriggered"
QT_MOC_LITERAL(22, 293, 30), // "onActionDeleteCommentTriggered"
QT_MOC_LITERAL(23, 324, 13), // "w_writeString"
QT_MOC_LITERAL(24, 338, 18), // "w_increaseDecrease"
QT_MOC_LITERAL(25, 357, 12), // "w_writeBytes"
QT_MOC_LITERAL(26, 370, 12), // "w_writeZeros"
QT_MOC_LITERAL(27, 383, 9), // "w_write64"
QT_MOC_LITERAL(28, 393, 13), // "w_writeRandom"
QT_MOC_LITERAL(29, 407, 16), // "w_duplFromOffset"
QT_MOC_LITERAL(30, 424, 19), // "w_writePascalString"
QT_MOC_LITERAL(31, 444, 17), // "w_writeWideString"
QT_MOC_LITERAL(32, 462, 14), // "w_writeCString"
QT_MOC_LITERAL(33, 477, 23), // "onKeyboardEditTriggered"
QT_MOC_LITERAL(34, 501, 7), // "enabled"
QT_MOC_LITERAL(35, 509, 21) // "onKeyboardEditChanged"

    },
    "HexWidget\0selectionChanged\0\0"
    "HexWidget::Selection\0selection\0"
    "positionChanged\0RVA\0start\0seek\0uint64_t\0"
    "address\0refresh\0updateColors\0"
    "onCursorBlinked\0onHexPairsModeEnabled\0"
    "enable\0copy\0copyAddress\0onRangeDialogAccepted\0"
    "onActionAddCommentTriggered\0"
    "onActionAddFlagTriggered\0"
    "onActionDeleteFlagTriggered\0"
    "onActionDeleteCommentTriggered\0"
    "w_writeString\0w_increaseDecrease\0"
    "w_writeBytes\0w_writeZeros\0w_write64\0"
    "w_writeRandom\0w_duplFromOffset\0"
    "w_writePascalString\0w_writeWideString\0"
    "w_writeCString\0onKeyboardEditTriggered\0"
    "enabled\0onKeyboardEditChanged"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_HexWidget[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      26,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  144,    2, 0x06 /* Public */,
       5,    1,  147,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       8,    1,  150,    2, 0x0a /* Public */,
      11,    0,  153,    2, 0x0a /* Public */,
      12,    0,  154,    2, 0x0a /* Public */,
      13,    0,  155,    2, 0x08 /* Private */,
      14,    1,  156,    2, 0x08 /* Private */,
      16,    0,  159,    2, 0x08 /* Private */,
      17,    0,  160,    2, 0x08 /* Private */,
      18,    0,  161,    2, 0x08 /* Private */,
      19,    0,  162,    2, 0x08 /* Private */,
      20,    0,  163,    2, 0x08 /* Private */,
      21,    0,  164,    2, 0x08 /* Private */,
      22,    0,  165,    2, 0x08 /* Private */,
      23,    0,  166,    2, 0x08 /* Private */,
      24,    0,  167,    2, 0x08 /* Private */,
      25,    0,  168,    2, 0x08 /* Private */,
      26,    0,  169,    2, 0x08 /* Private */,
      27,    0,  170,    2, 0x08 /* Private */,
      28,    0,  171,    2, 0x08 /* Private */,
      29,    0,  172,    2, 0x08 /* Private */,
      30,    0,  173,    2, 0x08 /* Private */,
      31,    0,  174,    2, 0x08 /* Private */,
      32,    0,  175,    2, 0x08 /* Private */,
      33,    1,  176,    2, 0x08 /* Private */,
      35,    1,  179,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 6,    7,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 9,   10,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   15,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   34,
    QMetaType::Void, QMetaType::Bool,   34,

       0        // eod
};

void HexWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<HexWidget *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->selectionChanged((*reinterpret_cast< HexWidget::Selection(*)>(_a[1]))); break;
        case 1: _t->positionChanged((*reinterpret_cast< RVA(*)>(_a[1]))); break;
        case 2: _t->seek((*reinterpret_cast< uint64_t(*)>(_a[1]))); break;
        case 3: _t->refresh(); break;
        case 4: _t->updateColors(); break;
        case 5: _t->onCursorBlinked(); break;
        case 6: _t->onHexPairsModeEnabled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 7: _t->copy(); break;
        case 8: _t->copyAddress(); break;
        case 9: _t->onRangeDialogAccepted(); break;
        case 10: _t->onActionAddCommentTriggered(); break;
        case 11: _t->onActionAddFlagTriggered(); break;
        case 12: _t->onActionDeleteFlagTriggered(); break;
        case 13: _t->onActionDeleteCommentTriggered(); break;
        case 14: _t->w_writeString(); break;
        case 15: _t->w_increaseDecrease(); break;
        case 16: _t->w_writeBytes(); break;
        case 17: _t->w_writeZeros(); break;
        case 18: _t->w_write64(); break;
        case 19: _t->w_writeRandom(); break;
        case 20: _t->w_duplFromOffset(); break;
        case 21: _t->w_writePascalString(); break;
        case 22: _t->w_writeWideString(); break;
        case 23: _t->w_writeCString(); break;
        case 24: _t->onKeyboardEditTriggered((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 25: _t->onKeyboardEditChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (HexWidget::*)(HexWidget::Selection );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&HexWidget::selectionChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (HexWidget::*)(RVA );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&HexWidget::positionChanged)) {
                *result = 1;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject HexWidget::staticMetaObject = { {
    QMetaObject::SuperData::link<QScrollArea::staticMetaObject>(),
    qt_meta_stringdata_HexWidget.data,
    qt_meta_data_HexWidget,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *HexWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *HexWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_HexWidget.stringdata0))
        return static_cast<void*>(this);
    return QScrollArea::qt_metacast(_clname);
}

int HexWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QScrollArea::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 26)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 26;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 26)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 26;
    }
    return _id;
}

// SIGNAL 0
void HexWidget::selectionChanged(HexWidget::Selection _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void HexWidget::positionChanged(RVA _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
