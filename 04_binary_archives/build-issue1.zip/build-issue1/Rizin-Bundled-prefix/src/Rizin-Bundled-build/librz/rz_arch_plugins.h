// SPDX-FileCopyrightText: 2024 RizinOrg <info@rizin.re>
// SPDX-License-Identifier: LGPL-3.0-only

// clang-format off
#ifndef RZ_ARCH_PLUGINS_BUILD_H
#define RZ_ARCH_PLUGINS_BUILD_H

#define RZ_ARCH_STATIC_PLUGINS &rz_arch_plugin_6502, &rz_arch_plugin_8051, &rz_arch_plugin_amd29k, &rz_arch_plugin_arm_as, &rz_arch_plugin_arm_cs, &rz_arch_plugin_avr, &rz_arch_plugin_bf, &rz_arch_plugin_chip8, &rz_arch_plugin_cil, &rz_arch_plugin_cr16, &rz_arch_plugin_dalvik, &rz_arch_plugin_dcpu16, &rz_arch_plugin_ebc, &rz_arch_plugin_gb, &rz_arch_plugin_h8300, &rz_arch_plugin_hexagon, &rz_arch_plugin_i4004, &rz_arch_plugin_i8080, &rz_arch_plugin_java, &rz_arch_plugin_lh5801, &rz_arch_plugin_lm32, &rz_arch_plugin_luac, &rz_arch_plugin_m680x_cs, &rz_arch_plugin_m68k_cs, &rz_arch_plugin_malbolge, &rz_arch_plugin_mcore, &rz_arch_plugin_mcs96, &rz_arch_plugin_mips_cs, &rz_arch_plugin_msp430, &rz_arch_plugin_null, &rz_arch_plugin_or1k, &rz_arch_plugin_pic, &rz_arch_plugin_ppc_as, &rz_arch_plugin_ppc_cs, &rz_arch_plugin_propeller, &rz_arch_plugin_pyc, &rz_arch_plugin_rl78, &rz_arch_plugin_rsp, &rz_arch_plugin_rx, &rz_arch_plugin_sh, &rz_arch_plugin_snes, &rz_arch_plugin_sparc_cs, &rz_arch_plugin_spc700, &rz_arch_plugin_sysz, &rz_arch_plugin_tms320, &rz_arch_plugin_v810, &rz_arch_plugin_v850, &rz_arch_plugin_wasm, &rz_arch_plugin_x86_as, &rz_arch_plugin_x86_cs, &rz_arch_plugin_x86_nasm, &rz_arch_plugin_x86_nz, &rz_arch_plugin_xap, &rz_arch_plugin_xcore_cs, &rz_arch_plugin_riscv_cs, &rz_arch_plugin_tricore_cs, &rz_arch_plugin_arc_gnu, &rz_arch_plugin_cris_gnu, &rz_arch_plugin_hppa_gnu, &rz_arch_plugin_lanai_gnu, &rz_arch_plugin_mips_gnu, &rz_arch_plugin_nios2_gnu, &rz_arch_plugin_riscv_gnu, &rz_arch_plugin_sparc_gnu, &rz_arch_plugin_vax_gnu, &rz_arch_plugin_xtensa_gnu, &rz_arch_plugin_z80_gnu

extern RzArchPlugin rz_arch_plugin_6502;
extern RzArchPlugin rz_arch_plugin_8051;
extern RzArchPlugin rz_arch_plugin_amd29k;
extern RzArchPlugin rz_arch_plugin_arm_as;
extern RzArchPlugin rz_arch_plugin_arm_cs;
extern RzArchPlugin rz_arch_plugin_avr;
extern RzArchPlugin rz_arch_plugin_bf;
extern RzArchPlugin rz_arch_plugin_chip8;
extern RzArchPlugin rz_arch_plugin_cil;
extern RzArchPlugin rz_arch_plugin_cr16;
extern RzArchPlugin rz_arch_plugin_dalvik;
extern RzArchPlugin rz_arch_plugin_dcpu16;
extern RzArchPlugin rz_arch_plugin_ebc;
extern RzArchPlugin rz_arch_plugin_gb;
extern RzArchPlugin rz_arch_plugin_h8300;
extern RzArchPlugin rz_arch_plugin_hexagon;
extern RzArchPlugin rz_arch_plugin_i4004;
extern RzArchPlugin rz_arch_plugin_i8080;
extern RzArchPlugin rz_arch_plugin_java;
extern RzArchPlugin rz_arch_plugin_lh5801;
extern RzArchPlugin rz_arch_plugin_lm32;
extern RzArchPlugin rz_arch_plugin_luac;
extern RzArchPlugin rz_arch_plugin_m680x_cs;
extern RzArchPlugin rz_arch_plugin_m68k_cs;
extern RzArchPlugin rz_arch_plugin_malbolge;
extern RzArchPlugin rz_arch_plugin_mcore;
extern RzArchPlugin rz_arch_plugin_mcs96;
extern RzArchPlugin rz_arch_plugin_mips_cs;
extern RzArchPlugin rz_arch_plugin_msp430;
extern RzArchPlugin rz_arch_plugin_null;
extern RzArchPlugin rz_arch_plugin_or1k;
extern RzArchPlugin rz_arch_plugin_pic;
extern RzArchPlugin rz_arch_plugin_ppc_as;
extern RzArchPlugin rz_arch_plugin_ppc_cs;
extern RzArchPlugin rz_arch_plugin_propeller;
extern RzArchPlugin rz_arch_plugin_pyc;
extern RzArchPlugin rz_arch_plugin_rl78;
extern RzArchPlugin rz_arch_plugin_rsp;
extern RzArchPlugin rz_arch_plugin_rx;
extern RzArchPlugin rz_arch_plugin_sh;
extern RzArchPlugin rz_arch_plugin_snes;
extern RzArchPlugin rz_arch_plugin_sparc_cs;
extern RzArchPlugin rz_arch_plugin_spc700;
extern RzArchPlugin rz_arch_plugin_sysz;
extern RzArchPlugin rz_arch_plugin_tms320;
extern RzArchPlugin rz_arch_plugin_v810;
extern RzArchPlugin rz_arch_plugin_v850;
extern RzArchPlugin rz_arch_plugin_wasm;
extern RzArchPlugin rz_arch_plugin_x86_as;
extern RzArchPlugin rz_arch_plugin_x86_cs;
extern RzArchPlugin rz_arch_plugin_x86_nasm;
extern RzArchPlugin rz_arch_plugin_x86_nz;
extern RzArchPlugin rz_arch_plugin_xap;
extern RzArchPlugin rz_arch_plugin_xcore_cs;
extern RzArchPlugin rz_arch_plugin_riscv_cs;
extern RzArchPlugin rz_arch_plugin_tricore_cs;
extern RzArchPlugin rz_arch_plugin_arc_gnu;
extern RzArchPlugin rz_arch_plugin_cris_gnu;
extern RzArchPlugin rz_arch_plugin_hppa_gnu;
extern RzArchPlugin rz_arch_plugin_lanai_gnu;
extern RzArchPlugin rz_arch_plugin_mips_gnu;
extern RzArchPlugin rz_arch_plugin_nios2_gnu;
extern RzArchPlugin rz_arch_plugin_riscv_gnu;
extern RzArchPlugin rz_arch_plugin_sparc_gnu;
extern RzArchPlugin rz_arch_plugin_vax_gnu;
extern RzArchPlugin rz_arch_plugin_xtensa_gnu;
extern RzArchPlugin rz_arch_plugin_z80_gnu;
// clang-format on

#endif